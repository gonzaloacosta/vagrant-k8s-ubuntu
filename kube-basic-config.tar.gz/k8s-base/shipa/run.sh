# install shipa

NAMESPACE=shipa-system
kubectl create namespace $NAMESPACE


cat > values.override.yaml << EOF
auth:
  adminUser: admin@example.com
  adminPassword: password
EOF

# previus to kubernetes deploy the storageclass with dynamic provision will be enabled

helm repo add shipa-charts https://shipa-charts.storage.googleapis.com

helm install shipa shipa-charts/shipa -n $NAMESPACE  --timeout=1000s -f values.override.yaml

# Install cliente
curl -s https://storage.googleapis.com/shipa-client/install.sh | sudo bash

