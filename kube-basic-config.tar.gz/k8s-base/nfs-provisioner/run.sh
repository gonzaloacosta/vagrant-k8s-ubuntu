# nfs-provisioner

# 1. Install the NFS Server

sudo mkdir /nfs/kubedata -p

sudo chown nobody:nogroup /srv/nfs/kubedata/

sudo chmod 777 /srv/nfs/kubedata

sudo apt install -y nfs-common nfs-kernel-server

sudo systemctl enable nfs-server

sudo bash -c "cat > /etc/exports" <<EOF
/srv/nfs/kubedata *(rw,sync,no_subtree_check,no_root_squash,no_all_squash,insecure)
EOF

# from client
sudo exportfs 

sudo mount -t nfs 172.42.42.100:/srv/nfs/kubedata /mnt

mount | grep kubedata 
172.42.42.100:/srv/nfs/kubedata on /mnt type

# 2) Deploying Service Account and Role Bindings

kubectl apply -f 00-rbac.yaml

# 3) Deploy Storage Class

kubectl apply -f 01-storageclass.yaml
kubectl apply -f 02-default-storageclass.yaml

# 4) Deploy NFS Provisioner

kubectl apply -f 03-deployment.yaml

# 5) 
# edit NFS Server IP
vi 03-deployment.yaml
...

kubectl apply -f deployment.yaml

# add into kube-apiserver.yaml this flag

/etc/kubernetes/manifests/kube-apiserver.yaml

Add this line:
- --feature-gates=RemoveSelfLink=false


# 5) Create pv and pvc

kubectl get pv,pvc

ls /srv/nfs/kubedata/


