# Environment variable

- Plain key value

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: myenv
spec:
  containers:
    - image: nginx
      name: mypod
    env:
      - name: APP_COLOR
        value: pink
```

- ConfigMap

```yaml
env:
  - name: APP_COLOR
    valueFrom:
      configmapKeyRef:
```

- Secrets

```yaml
env:
  - name: APP_COLOR
    valueFrom:
      secretKeyRef:
```


