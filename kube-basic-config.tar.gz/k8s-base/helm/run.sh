#!/bin/bash

echo "Install helm tools.."
sudo snap install helm --classic
