# Create secret

## Imperative

```bash
kubectl create secret generic  app-secret \
    --from-literal=DB_Host=mysql \
    --from-literal=DB_User=root \
    --from-literal=DB_Password=passwd

kubectl create secret generic app-secret \
    --from-file=app_secret.properties
```

## Declarative

```yaml
vim secret.yaml
apiVersion: v1
kind: Secret
metadata:
  name: app-secret
data:
  DB_Host: mysql
  DB_User: root
  DB_Password: passwd

kubectl create -f secret.yaml
```

## Secrets in Pod

- Env

```yaml
envFrom:
  - secretRef:
      name: app-secret
```

- Sinble Env 

```yaml
env:
  - name: DB_Password
    valueFrom:
      secretRef:
        name: app-secret
        key: DB_Password
```

- Volume

```yaml
volumes:
- name: app-secret-volumes
  secret:
    secretName: app-secret
```

```bash
ls /opt/app-secret-volumes
DB_Host DB_Password DB_User

cat /opt/app-secret-volumes/DB_Password
passwd
```


