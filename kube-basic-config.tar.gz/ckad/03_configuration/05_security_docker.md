# Security

## Docker

- Namespace
	- Each process run in kernel namespace.
	- SO has a main namespace (root)
- Process
	- Each container run your process in your specific namespace.
	- Each process in each container run with your user id, for example sleep process run with process id 1
	- Each container process in SO level run with other process id but in each your specific namespace.
- User 
	- Each process by default, run with root.
	- Root user in container is the same root user in host (DANGER!)
	- User could be changed by dockerfile or argument
- Capabilities
	- To protect user actions in container, linux implement capabilities 
	- By default NOT all the capability are available, you need to add.
	- Capabilities provides access to
		- /usr/include/linux/capability.h

## Kubernetes

- Security
	- Implement in capability
	- Are implemented in pod or contianer, if implement in container overwrite setting in a pod

- Pod level

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: mypod
spec:
  securityContext:
	runAsUser: 1000
	capabilities:
	  add: ["MAC_ADMIN"]
  containers:
    - name: mypod
	  image: myimage
```

- Container level

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: mypod
spec:
  containers:
    - name: mypod
	  image: myimage
	  securityContext:
	    runAsUser: 1000
		capabilities:
		  add: ["MAC_ADMIN"]
```
